## Install node modules
```sh
cd lambda
npm install
```

## deploy
All deployments to the master branch are directly pushed to the codecommit repo and pushed to the lambda working in production.
This changes will be immediately live in the production version of the alexa skill.
```sh
git add .
git commit -m "..."
git push origin master
```

## See alexa skill in the console
Go to
https://developer.amazon.com/alexa/console/ask/build/custom/amzn1.ask.skill.b5c5a8e0-37e1-4ca9-9735-71977f32464a/development/en_GB/dashboard

To login to the console, ask for permission to Night Zookeeper. at the moment there are 2 dev accounts: for salih@aflorithmic.ai and antonio@aflorithmic.ai

## Test the alexa skill in production using the phone
1. Download "Amazon Alexa" app from the app store.
2. Login with any amazon account. Can be the same as the console
3. In the app, go to More / Settings / Account Settings / Alexa App Settings / Language -> Choose English (United Kingdom)
4. In the app, go to More / Skills & Games / Search and type Night Zookeeper and click on "Enable Skill"
5. In the app, Go to Home and say "Alexa, open Night Zookeeper".