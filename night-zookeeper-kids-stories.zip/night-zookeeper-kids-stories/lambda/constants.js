module.exports = {
  dynamoDBTableName: "b5c5a8e0-37e1-4ca9-9735-71977f32464a"
};
